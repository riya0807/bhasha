var account = [ 
    {
        username: "riya",
        password: "patel",
        level: "2"
    }, 
    {
        username: "u",
        password: "p",
        level: "1"
    },
    {
        user: "admin",
        pass: "hello",
        level: "4"
    }
]

function validateForm() {
              var u = document.getElementbyId('username');
              var p = document.getElementbyId('pass');
           	  s = prompt("please enter your password");
           // alert("hello");
            for(var i = 0; i < account.length; i++) {
              if (s == account[i].username) {
              	alert("hello");

                //console.log("success");
                window.location.href="index.html"; //page to redirect if password entered is correct
        		//return true;
              } else {
                console.log("Incorrect");
                alert("Incorrect username or password. Try again");
                //return false;
              }
            }
              
}

function checkAccess() {

}