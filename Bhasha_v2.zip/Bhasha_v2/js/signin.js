var text;

class Account {
	constructor(username, password, security) {
		var lvl = 1;
		this.username = user;
		this.password = pass;
		this.security = ans;
		var acctList = $.csv.toArray(input);
	}
	
	getUsername() {
			return user;
	}
	getPass() {
			return pass;
	}
	updateLevel(newLevel) {
		lvl = newLevel;
	}
}

function signUp()) {
	var username = document.getElementById("username").value();
	var password = document.getElementById("password").value();
	var security = document.getElementById("security").value();
	nAccount = new Account(username, password, security);
	acctList[acctList.length] = nAccount;
}

function signIn() {
	var user = prompt("What is your username?");
	var valid = false;
	var index = 0;
	var acctList = $.csv.toArray(input);
	for(int i = 0; i < acctList.length; i++) {
		if(user == acctList[i].getUsername()) {
			document.getElementById("demo").innerHTML = "Hello " + user + "! How are you today?";
			valid = true;
			index = i;
		} else if(i = acctList.length - 1) {
			document.getElementById("demo").innerHTML = "This is the wrong username. Please either try again or sign up.";
		}
	}
	var pass = prompt("What is your password?");
	if(valid && pass == acctList[index].getPass()) {
		document.getElementById("demo").innerHTML = "Hello! How are you today?";
	} else {
		document.getElementById("demo").innerHTML = "This is the wrong password. Please either try again or sign up.";
	}
}