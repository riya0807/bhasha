$(".flippable").click(function(){
  $(this).toggleClass("flipme");
});